public class invTest{

  public static void main(String[] args){
    InventoryManager inv1 = new InventoryManager();
    inv1.takeInventory();
  }
}
